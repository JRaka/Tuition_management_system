<?php
    session_start();
    if(isset($_SESSION['isloggedin']) && $_SESSION['isloggedin']==true){
?>
<!DOCTYPE html>
   
     <html>

       <head>
    
          <meta charset="utf-8">
          <title>Update Page</title>
       <!--css code-->
         
         
    </head>
        <body>
            
            
            <?php
               include "dbconnection.php";
        
               if(isset($_POST['up_row_no']))
               {
                   $up_row=$_POST['up_row_no'];
                   
                   $mysqlquery="select * from teacher where email=$up_row";
                   
                   try{
                       $ret=$conn->query($mysqlquery);
                       $table=$ret->fetchAll();
                       $row=$table[0];
                       
                   }
                   catch(PDOException $ex){
                        echo "<script>location.assign('home.php')</script>";
                      }
                   }
               
               else{
                   echo "<script>location.assign('home.php')</script>";
               }
        
          ?>
            
            
      <form action="renewData.php" method="post">
              
              
              
          Email: <input type="email" id="uemail" name = "uemail"  value="<?php echo $row['email']?>"readonly>
          <br/><br/>
          Password: <input type="password" id="upass" name="upass" value="<?php echo $row['password']?>" readonly>
          <br/><br/>
          Name: <input type="text" id="uname" name="uname"  value="<?php echo $row['name']?>" readonly>
          <br/><br/>
          Subject: <input type="text" id="usubject" name="usubject"  value="<?php echo $row['subject']?>">
          <br/><br/>
           Phone_num: <input type="text" id="uphone_num" name="uphone_num"  value="<?php echo $row['Phone_num']?>">
          <br/><br/>
          Qualification: <input type="text" id="uqualification" name="uqualification"  value=" <?php echo $row['Qualification']?>">
           <br/><br/>
          Salary: <input type="text" id="usalary" name="usalary"  value="<?php echo $row['salary']?>">
          <br/><br/>
          Address: <input type="text" id="uaddress" name="uaddress"  value="<?php echo  $row['address']?>">
          <br/><br/>
          
          
          
                 
          <input type="submit" value="Update">
            
        </form>
      </body>
   </html>
<?php
}
    else{
        ///already not logged in
        echo "<script>location.assign('login.php')</script>";
    }
?>