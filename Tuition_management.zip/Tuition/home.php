
<?php
    session_start();
   if(isset($_SESSION['isloggedin']) && $_SESSION['isloggedin']==true){
       ?>

<!DOCTYPE html>

<html>

     <head>
    
          <meta charset="utf-8">
          <title>Login Page</title>
       <!--css code-->
         <style>
              
         body {
               background-color: cyan;
          }
         
             table{
                 width: 100%;
                 
             }
             table, th,td{
                 border:1px solid blue;
                 text-align: center;
                 
                 border-collapse: collapse;
             }
         
             tr:hover{
                 background-color: #00bfff;
             } 
         </style>
         
    </head>
      <body>
    
         WELCOME TO  <?php echo $_SESSION['teacheremail'] ?>
         <br/><br/>
          
          <!--information show-->
          <table>
              <thread>
                 
                  <tr>
                      <th>email</th>
                      <th>password</th>
                      <th>name</th>
                      <th>subject</th>
                      <th>phone number</th>
                      <th>qualification</th>
                      <th>salary</th>
                      <th>address</th>
                      <th>update/delete</th><br><br/>
                 
                  </tr>  
              
              </thread>
              <tbody>
     <?php
               ///database connection, mysqli(procedure, object), PDO(object)
        try{
            ///try to build up the connection
            $conn=new PDO("mysql:host=localhost:3307;dbname=tb","root","");
            
            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            
            $mysqlquery="select * from teacher";
            
            $ret=$conn->query($mysqlquery); //$ret object
            
            $table=$ret->fetchAll(); //extracting table
            
            for($i=0;$i<count($table);$i++)
            {
                
                $row=$table[$i] ;  //each row
                ?>
                   <tr>
                      <td><?php echo $row['email']?></td>
                      <td><?php echo $row['password']?></td>
                      <td><?php echo $row['name']?></td>
                      <td><?php echo $row['subject']?></td>
                      <td><?php echo $row['phone_num']?></td>
                      <td><?php echo $row['qualification']?></td>
                      <td><?php echo $row['salary']?></td>
                      <td><?php echo $row['address']?></td>
                      <td>
                          <form action="update.php" method="post">
                              <input type="hidden" value="<?php echo $row['email']?>" name="up_row_no">
                         <input type = "button" value="Update">
                          </form>
                          
                         <input type = "button" value="Delete" onclick="delme(<?php echo $row['email']?>)">
                           
                       
                       </td>
                 
                  </tr>  
                  
            <?php
                      
            }
            
            
        }
        catch(PDOException $ex){
            ///no connection with database
        ?>    
           <script>alert("Database connection error")</script>
    
        <?php          
           
        }
                           
           ?>           
              </tbody>                
          </table>
          
          <br/> 
          
        <a href="logout.php">Logout</a>
     
          <script>
                function delme(row_num){
                    location.assign("delete.php?del_row_no="+row_num);
                    
                }
          
          
          </script>
    
      </body>

</html>


<?php
       
   }
   else {
       
       echo "<script>location.assign('login.php')</script>";
   }
    
?>

