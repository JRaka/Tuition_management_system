<?php

    if(isset($_POST['signup'])) {
        ///getting post values
        $uemail=$_POST['uemail'];
        $upassword=$_POST['upassword'];  
        $uphone_no=$_POST['uphone_no'];
        
        
        
        
        ///database connection, mysqli(procedure, object), PDO(object)
        try{
            ///try to build up the connection
            $conn=new PDO("mysql:host=localhost:3307;dbname=tb","root","");
            
            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        }
        catch(PDOException $ex){
            ///no connection with database
            echo "<script>location.assign('login.php')</script>";
        }
    
        
        ///database connection successful
        $mysqlquery1="select * from tcr where email='$uemail'"; ///mysql code generated php
        
        ///echo $mysqlquery;
        
        ///processing
        $ret=$conn->query($mysqlquery); ///execute the msyql query in database
        
        if($ret->rowCount()==1){
            echo "<script>location.assign('signup.php')</script>";
        }
        else{
           $mysqlquery="insert into tcr  VALUES ('$uemail','$upassword','$uphone_no')";
            
            try{
                $conn->exec($mysqlquery);
                echo "<script>location.assign('login.php')</script>";
            }
            catch(PDOException $ex){
                echo "<script>location.assign('signup.php')</script>";
            }
        }
    }
    else{
        ///jodi uemail and upass set kora hoy nai
        ///return login page
        echo "<script>location.assign('login.php')</script>";
    }   

?>