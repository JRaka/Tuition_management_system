<?php
    session_start();
    if(isset($_SESSION['isloggedin']) && $_SESSION['isloggedin']==true){
?>


<?php
        
     if(isset($_GET['del_row_no']))
     {      
          $del_row= $_GET['del_row_no']; 
         
         include "dbconnection.php";
           
        
         $mysqlquery ="delete from teacher where email=$del_row ";
          
         try{
             $conn->exec($mysqlquery) ;
              echo "<script>location.assign('home.php')</script>";     
         }
         catch(PDOException $ex)
         {
              echo "<script>location.assign('home.php')</script>";     
         }
        }
     else{        
        echo "<script>location.assign('home.php')</script>";                      
     }
        
        
        
 ?>


<?php
    }
    else{
        ///already not logged in
        echo "<script>location.assign('login.php')</script>";
    }
?>