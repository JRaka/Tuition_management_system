
<html>
    
      <head>
          <meta charset = "utf-8"
          <title>Tuition Management System</title>
        <br/><br/>
          

      </head>
        
      <body>
          <style>
         body {
               background-color: cyan;
          }
          </style>
        
        <form action="verifylogin.php" method="post">
          Email : <input type="email" id="uemail" name = "uemail">
          <br/><br/>
          Password: <input type="password" id="upass" name="upass">
          <br/><br/>
          <input type="submit" value="Log in">
            
        </form>

      </body>

</html>
