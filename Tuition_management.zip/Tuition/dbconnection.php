 

<?php


///database connection, mysqli(procedure, object), PDO(object)
        try{
            ///try to build up the connection
            $conn=new PDO("mysql:host=localhost:3307;dbname=tb","root","");
            
            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        }
        catch(PDOException $ex){
            ///no connection with database
            echo "<script>location.assign('login.php')</script>";
            //echo diye php er mdhe js likha jai
        }

?>