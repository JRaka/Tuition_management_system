<?php

    if(isset($_POST['uemail']) && isset($_POST['upass'])){
        //saving the values to other variables
        $uemail=$_POST['uemail'];
        $upass=$_POST['upass'];
        
        ///database connection, mysqli(procedure, object), PDO(object)
        try{
            ///try to build up the connection
            $conn=new PDO("mysql:host=localhost:3307;dbname=tb","root","");
            
            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        }
        catch(PDOException $ex){
            ///no connection with database
            echo "<script>location.assign('login.php')</script>";
            //echo diye php er mdhe js likha jai
        }
        
        
        ///database connection successful
        $mysqlquery="select * from teacher where email='$uemail' and password='$upass'"; ///mysql code generated php
        
        //echo $mysqlquery;
        
        $ret=$conn->query($mysqlquery);///execute sql query in database
        
        if($ret->rowCount()==1){
            //forward to homepage
            session_start();
            $_SESSION['isloggedin']=true;
            $_SESSION['teacheremail']=$uemail;
            echo "<script>location.assign('home.php')</script>";
        } 
        else{
            ///forward to login page
            $_SESSION['isloggedin']=false;
            echo "<script>location.assign('login.php')</script>";
        }
        
        
    }
    else{
        ///jodi uemail and upass set kora hoy nai
        ///return login page
        echo "<script>location.assign('login.php')</script>";
    }   
?>