<?php
    session_start();
    if(isset($_SESSION['isloggedin']) && $_SESSION['isloggedin']==true){
?>
    <?php

        if(isset($POST['uemail']) && isset($POST['upassword']) && isset($POST['uname']) && isset($POST['usubject']) && isset($POST['uphone_num']) && isset($POST['uqualification']) && isset($POST['usalary']) && isset($POST['uaddress'])){
            
            
            $uemail = $_POST['uemail'];
            $upassword = $_POST['upassword'];
            $uname = $_POST['uname'];
            $usubject = $_POST['usubject'];
            $uphone_num = $_POST['uphonenum'];
            $uqualification = $_POST['uqualification'];
            $usalary = $_POST['usalary'];
            $uaddress = $_POST['uaddress'];
            
            include "dbconnection.php";
            
            $mysqlquery="update teacher set  name = '$uname', subject ='$subject', phone_num='$phonenum', qualification = '$qualification', salary = '$salary', address= '$salary' where email = $uemail";
            
            try{
                $conn->exec($mysqlquery);
                echo"<script>location.assign('home.php')</script>";
            }
            catch{
                
            }
        }
        else
        {
            echo "<script>location.assign('update.php')</script>";
        }


?>

<?php
    }
    else{
        ///already not logged in
        echo "<script>location.assign('login.php')</script>";
    }
?>