
<!DOCTYPE html>

<html>
    <head>
        <meta charset="utf-8">
        <title>Signup Page</title>
       
    </head>
    
    <body>
        <style>
         body {
               background-color: cyan;
          }
          </style>
           <form action="register.php" method="post">
             Email: <input type="email" id="uemail" name="uemail">
             <br/><br/>
             Password: <input type="password" id="upass" name="upass">
              <br/><br/>
              Phone_num: <input type= "text" id="unumber" name="unumber">
              <br/><br/>
             <input type="submit" value="Sign Up">
        </form>
    </body>
</html>